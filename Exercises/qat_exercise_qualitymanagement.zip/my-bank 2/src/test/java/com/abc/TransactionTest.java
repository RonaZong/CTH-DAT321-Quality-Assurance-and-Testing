package com.abc;

import org.junit.Before;
import org.junit.Test;

import java.util.Locale;

import static org.junit.Assert.assertTrue;

public class TransactionTest {

    @Before
    public void setLocale(){
        Locale.setDefault(Locale.US);
    }

    @Test
    public void transaction() {
        Transaction t = new Transaction(5);
        assertTrue(t instanceof Transaction);
    }
}
