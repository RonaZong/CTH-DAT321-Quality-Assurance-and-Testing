## About This Project

This project provides a minimal example of how to apply mutation testing with PIT in a Java codebase. It is designed to demonstrate how PIT introduces small faults (mutations) into the code and evaluates whether the existing test suite can detect them. By running PIT on this project, you can explore mutation operators, review coverage reports, and understand how mutation testing helps assess and improve the effectiveness of your tests.

## Exercise Instructions

A description of the tasks can [be found here.](https://docs.google.com/document/d/1yzKDtITI2hTosujn9tX_VQ-a_ZTjUbbstVToXQxkISE/edit?tab=t.0)