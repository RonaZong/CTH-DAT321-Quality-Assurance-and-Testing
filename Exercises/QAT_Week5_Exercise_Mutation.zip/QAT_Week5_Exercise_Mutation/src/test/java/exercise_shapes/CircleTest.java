package exercise_shapes;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class CircleTest {

    @Test
    public void shouldCreateValidCircle(){
        Circle circle = new Circle(10);
        int expectedRadius = 10;
        assertEquals(expectedRadius, circle.getRadius());

        circle = new Circle(10);
        assertEquals(10, circle.getRadius());
        assertEquals(10, circle.getRadius());

        circle = new Circle(15);
        assertEquals(15, circle.getRadius());
        circle.setRadius(10);
        assertEquals(10, circle.getRadius());

        // circle = new Circle(-5);
        // assertEquals(-5, circle.getRadius());
    }


}
