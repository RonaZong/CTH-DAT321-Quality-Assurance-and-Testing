package exercise_shapes;

public class Square extends Rectangle {

    public Square(int side) {
        super(side, side);
    }
}
