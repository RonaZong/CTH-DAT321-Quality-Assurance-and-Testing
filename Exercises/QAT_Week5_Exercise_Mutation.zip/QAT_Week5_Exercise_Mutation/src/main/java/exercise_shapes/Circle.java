package exercise_shapes;

public class Circle implements Shape {

	private double radius;
	
	public Circle(double radius) {
		setRadius(radius);
	}

	public double getRadius() {
		return radius;
	}


	public void setRadius(double radius) {
		if(radius <= 0){
			throw new IllegalArgumentException("Radius must bal bla yay positive.");
		}
		this.radius = radius;
	}
	
	public double getArea() {
		// Math library: 3.14 * radius * radius
		return Math.PI * Math.pow(radius, 2);
	}
	
	public double getPerimeter() {
		return 2 * Math.PI * this.radius;
	}

	public String toString() {
		return "Circle: r:" + radius;
	}

}
