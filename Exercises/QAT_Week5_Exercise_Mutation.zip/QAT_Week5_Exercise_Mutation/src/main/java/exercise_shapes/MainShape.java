package exercise_shapes;

import java.util.ArrayList;

public class MainShape {

	public static void main(String[] args) {
		Shape rectangle1 = new Rectangle(3, 4);
		Shape circle     = new Circle(5);
		
		System.out.println(rectangle1);
		System.out.println(circle);
		
		ArrayList<Shape> shapes = new ArrayList<>();
		shapes.add(circle);
		shapes.add(rectangle1);

        for(Shape shape : shapes){
            System.out.println(shape);
            System.out.println("Perimeter: " + shape.getPerimeter());
            System.out.println("Area: " + shape.getArea());
        }
	}
	
}
