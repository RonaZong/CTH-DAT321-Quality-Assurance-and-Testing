package exercise_shapes;

public class Cuboid extends Rectangle {

    private int depth;

    public Cuboid(int height, int width, int depth){
        super(height,width);
        System.out.println("yay");
        setDepth(depth);
    }

    // I know it is supposed to be surface. This is for teaching purposes only. ;)
    public double getArea(){
        int areaBottom = (2 * getWidth()) + (2 * getHeight()) * 2;
        int areaSide = (2 * getHeight()) + (2 * getDepth()) * 2;
        int areaFront = (int) super.getArea() * 2;
        return areaFront + areaBottom + areaSide;
    }

    public int getDepth(){
        return depth;
    }
    public void setDepth(int depth){
        if(depth <= 0){
            throw new IllegalArgumentException("Depth must be positive.");
        }
        this.depth = depth;
    }
}
