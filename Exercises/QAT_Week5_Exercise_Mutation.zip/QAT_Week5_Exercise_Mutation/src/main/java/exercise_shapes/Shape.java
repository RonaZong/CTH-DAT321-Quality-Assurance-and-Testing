package exercise_shapes;

public interface Shape {

	double getArea();
	double getPerimeter();

}
