package exercise_shapes;

public class Rectangle implements Shape {

	private int height;
	private int width;
	
	public Rectangle(int height, int width) {
		setHeight(height);
		setWidth(width);
	}

	public double getArea() {
		return this.height * this.width;
	}
	public double getPerimeter() {
		return (2 * this.height) + (2* this.width);
	}

	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		if(height <= 0){
			throw new IllegalArgumentException("Height must be positive.");
		}
		this.height = height;

	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		if(width <= 0){
			throw new IllegalArgumentException("Width must be positive.");
		}
		this.width = width;
	}

	@Override
	public String toString() {
		return "Rectangle: " + height + " x " + width;
	}
}
